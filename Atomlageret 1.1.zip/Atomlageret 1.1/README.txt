This is a windows version only.
Run the Med6-ChemiclaGame.exe to play the game.